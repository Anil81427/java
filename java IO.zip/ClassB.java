package quack7;

import java.io.FileInputStream;
import java.io.FileOutputStream;

public class ClassB 
{
	void meth1() throws Exception
	{
		FileInputStream fi=new FileInputStream("C:\\file\\file3.txt");
		int i;
		while((i=fi.read())!=-1)
		{
			System.out.println((char)i);
		}
		fi.close();
	}
	void meth2() throws Exception
	{
		FileOutputStream fo=new FileOutputStream("C:\\file\\file4.txt");
		String s="java is aewsome";
		fo.write(s.getBytes());
		fo.close();
	}
	
	
	public static void main(String[] args) throws Exception 
	{
		ClassB aobj=new ClassB();
		aobj.meth1();
		ClassB bobj=new ClassB();
		bobj.meth2();
	}

}
