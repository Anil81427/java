package quack7;

import java.io.BufferedReader;
import java.io.FileReader;

public class ClassG
{
	void meth1() throws Exception
	{
		BufferedReader br=new BufferedReader(new FileReader("C:\\file\\file3.txt"));
		int i;
		while ((i=br.read())!=-1)
		{
			System.out.println((char)i);
		}
		br.close();
	}
	public static void main(String[] args) throws Exception
	{
		new ClassG().meth1();
		
	}

}
