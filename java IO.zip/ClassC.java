package quack7;


import java.io.BufferedInputStream;
import java.io.FileInputStream;


public class ClassC
{
	void meth1() throws Exception
	{
		BufferedInputStream bis=new BufferedInputStream(new FileInputStream("C:\\file\\file3.txt"));
		int i;
		while((i=bis.read())!=-1)
		{
			System.out.println((char)i);
		}
		bis.close();
	}
	public static void main(String[] args) throws Exception
	{
		new ClassC().meth1();
		
	}
}
