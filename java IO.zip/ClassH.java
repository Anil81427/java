package quack7;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class ClassH 
{
	void meth1() throws Exception
	{
		BufferedReader br=new BufferedReader(new FileReader("C:\\file\\file3.txt"));
		int i;
		while ((i=br.read())!=-1)
		{
			System.out.println((char)i);
		}
		br.close();
	}
	void meth2() throws IOException
	{
		BufferedWriter bw=new BufferedWriter(new FileWriter("C:\\file\\file8.txt",true));
		String s="java";
		System.out.println(s.getClass());
		bw.close();
	}
	public static void main(String[] args) throws Exception 
	{
		new ClassH().meth1();
		new ClassH().meth2();
	}

}
