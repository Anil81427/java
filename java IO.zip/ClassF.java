package quack7;

import java.io.FileReader;
import java.io.FileWriter;

public class ClassF 
{
	void meth1() throws Exception
	{
		FileReader fr=new FileReader("C:\\file\\file3.txt");
		int i;
		while((i=fr.read())!=-1)
		{
			System.out.println((char)i);
			
		}
		fr.close();
	}
	void meth2() throws Exception
	{
		FileWriter fw=new FileWriter("C:\\file\\file5.txt",true);
		String s=",java";
		fw.write(s);
		fw.close();
	}
		
	public static void main(String[] args) throws Exception
	{
		ClassF conj=new ClassF();
		//conj.meth1();
		conj.meth2();		
	}

}
