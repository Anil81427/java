package quack7;

import java.io.FileInputStream;

public class ClassA 
{
	void meth1() throws Exception
	{
		FileInputStream fi=new FileInputStream("C:\\file\\file3.txt");
		int i;
		while((i=fi.read())!=-1)
		{
			System.out.println((char)i);
		}
		fi.close();
	}
	public static void main(String[] args) throws Exception
	{
		new ClassA().meth1();
		
	}
}
