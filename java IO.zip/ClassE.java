package quack7;
import java.io.FileReader;


public class ClassE
{
	void meth1() throws Exception
	{
		FileReader fr=new FileReader("C:\\file\\file4.txt");
		int i;
		while((i=fr.read())!=-1)
		{
			System.out.println((char)i);
			
		}	
		fr.close();
	}
	public static void main(String[] args) throws Exception 
	{
		new ClassE().meth1();
		
		
	}

}
