package quack7;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.FileInputStream;
import java.io.FileOutputStream;

public class ClassD 
{
	void meth1() throws Exception
	{
		BufferedInputStream bis=new BufferedInputStream(new FileInputStream("C:\\file\\file3.txt"));
		int i;
		while((i=bis.read())!=-1)
		{
			System.out.println((char)i);
		}
		bis.close();
	}
	void meth2() throws Exception
	{
		BufferedOutputStream bos=new BufferedOutputStream(new FileOutputStream("C:\\file\\file3.txt"));
		String s="java";
		bos.write(s.getBytes());
		bos.close();
		
	}
	public static void main(String[] args) throws Exception 
	{
		new ClassD().meth1();
		new ClassD().meth2();
	}

}
