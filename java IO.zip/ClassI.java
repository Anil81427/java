
package quack7;

import java.io.FileInputStream;

public class ClassI 
{
	void meth1() throws Exception
	{
		FileInputStream fi=new FileInputStream("C:\file\file4.txt");
		int i;
		while ((i=fi.read())!=-1)
		{
			System.out.println((char)i);
		}
		fi.close();
	}
	public static void main(String[] args) throws Exception 
	{
		new ClassI().meth1();
		
	}

}
