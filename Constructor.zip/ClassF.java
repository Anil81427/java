package quack4;

public class ClassF 
{
	private int a;
	private String s;
	public int getA()
	{
		return a;
	}
	public void setA(int a) 
	{
		this.a = a;
	}
	public String getS() 
	{
		return s;
	}
	public void setS(String s) 
	{
		this.s = s;
	}
	ClassF(int a,String s)
	{
		this.a=a;
		this.s=s;
	}
	public static void main(String[] args) 
	{
		ClassF fobj=new ClassF(10, "java");
		System.out.println("inital values "+"s:"+fobj.getS()+" a:"+" "+fobj.getA());
		
		fobj.setA(20);
		fobj.setS("Hello");
		System.out.println("Final values "+"s:"+fobj.getS()+" a:"+" "+fobj.getA());
	}
	
	
}

