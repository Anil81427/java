package quack4;

public class ClassD
{
	void meth1()
	{
		System.out.println("meth1 Called");
	}
	ClassD(int a)
	{
	 System.out.println("default constructor a:"+a);	
	}
	protected ClassD(int a,int b)
	{
		System.out.println("protected constructor a:"+a+" "+"b:"+b);
	}
	public ClassD(int a ,int b,int c)
	{
		System.out.println("public constructor a:"+a+" "+"b:"+b+" "+"c:"+c); 
	}
	private ClassD(int a,int b,int c,int d)
	{
		System.out.println("private constructor a:"+a+" "+"b:"+b+" "+"c:"+c+" "+"d"+" "+d);
	}
	public static void main(String[] args)
	{
		new ClassD(15);
		new ClassD(15,14);
		new ClassD(15,4,21);
		new ClassD(15,4,21,7);
	}

}
