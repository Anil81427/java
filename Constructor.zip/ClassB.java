package quack4;

public class ClassB 
{
	ClassB()
	{
		System.out.println("non-parameterized constructor");
	}
	ClassB(int a)
	{
		System.out.println("single parameterized constructor:"+a);
	}

}
