package quack4;

public class ClassA
{
	ClassA()
	{
		System.out.println("non-parameterized constructor");
	}
	ClassA(int a)
	{
		System.out.println("one parameterized constructor");
	}
	ClassA(int a,int b)
	{
		System.out.println("two parameterized constructor");
	}
	public static void main(String[] args)
	{
		new ClassA();
		new ClassA(15);
		new ClassA(4);
	}

}
