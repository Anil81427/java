package quack4;

public class ClassE
{
	
	String s;
	int a;
	
	public ClassE(int a)
	{
		this.a=a;
	}
	public ClassE(String s)
	{
		this.s=s;
	}
	public int meth1()
	{
		System.out.println("calling int constructor a:"+a);
		return this.a;
	}
	public String meth2()
	{
		System.out.println("calling String constructor s:"+s);
		return this.s;
	}
	public static void main(String[] args)
	{
		new ClassE(10).meth1();
		new ClassE("java").meth2();
	}

}
