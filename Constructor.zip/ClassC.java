package quack4;

public class ClassC 
{
	public static void main(String[] args) 
	{
		new ClassB();
		new ClassB(15);
		
	}
	

}
