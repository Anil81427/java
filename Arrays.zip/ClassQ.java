package pack5;

public class ClassQ 
{
	public void meth()
	{
		int arr=0;
		for(int i=1;i<=100;i++) 
		{
			arr=i*(i+1)/2;
			
		}
		
		System.out.println(arr-1);
	
	}
	
	public static void main(String[] args) 
	{
		
		new ClassQ().meth();
		
	}
		

}
