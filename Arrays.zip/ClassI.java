package pack5;

import java.util.Arrays;

public class ClassI
{
	void meth1()
	{
		int arr[]= {4,4,1,3,2};
		Arrays.sort(arr);
		for(int i=0;i<arr.length;i++)
		{
			for(int j=i+1;j<arr.length ;j++)
			{
				if(arr[i]==arr[j])
				{
					System.out.println(arr[i]);
				}
			}
		}
	}
	public static void main(String[] args) 
	{
		new ClassI().meth1();
		
	}

}
