package pack5;

import java.util.Arrays;

public class ClassF
{
	public static int[] meth1(int n,int arr[],int x)
	{
		
		int newarr[]=new int[n+1];
		for(int i=0;i<n;i++)
		{
			
			newarr[i]=arr[i];
			newarr[n]=x;
			
		}
		return newarr;
		
	}
	public static void main(String[] args)
	{
		int arr[]= {10,20};
		int n=2;
		int x=30;
		arr=meth1(n,arr,x);
		System.out.println(Arrays.toString(arr));
		
		
		
	}
}
	








