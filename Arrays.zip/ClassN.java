package pack5;

public class ClassN 
{
	void meth()
	{
		int arr[]= {10,20,20,40};
		int max=arr[0];
		int min=arr[0];
		for(int i=1;i<arr.length;i++)
		{
			if(arr[i]>max)
			{
				max=arr[i];
			}
			else if(arr[i]<min)
			{
				min=arr[i];
			}
		}
		int a=max-min;
		System.out.println(a);
		
	}
	public static void main(String[] args)
	{
		new ClassN().meth();
		
	}

}
