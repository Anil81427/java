package pack5;

import java.util.Arrays;

public class ClassH
{
	void meth1()
	{
		int arr[]= {1,2,3,4,5};
		Arrays.sort(arr);
		int i=0;int j=arr.length-1;
		while(i<j)
		{
		int temp=arr[i];
		arr[i]=arr[j];
		arr[j]=temp;
		i++;j--;
		}
		for(int O:arr)
		{
			System.out.print(O+" ");
		}
	}	
	public static void main(String[] args)
	{
		
		new ClassH().meth1();	
	}
}
