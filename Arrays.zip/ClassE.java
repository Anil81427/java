package pack5;

public class ClassE 
{
	void meth1()
	{
		int[] arr=new int[]{10,20,30,40,50};
		int[] arr1=arr;
		for(int num:arr1)
		{
			System.out.println(num);
		}
		
		
	}
	public static void main(String[] args) 
	{
		new ClassE().meth1();
		
	}

}
