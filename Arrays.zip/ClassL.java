package pack5;

import java.util.Arrays;

public class ClassL 
{
	void meth1()
	{
		int array[]= {10,20,30,40};
		Arrays.sort(array);
		
		System.out.println(array[array.length-2]);
	}
	
	public static void main(String[] args)
	{
		new ClassL().meth1();
		
	}

	

}
