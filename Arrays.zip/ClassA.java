package pack5;

public class ClassA 
{
	void meth()
	{
		int arr[]= {1,2,3,4,5};
		int s=0;
		for (int i=0;i<arr.length ;i++)
		{
			s=s+arr[i];
		}
		System.out.println(s);
	}
	public static void main(String[] args) 
	{
		new ClassA().meth();
		
	}
	

}
