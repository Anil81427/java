package pack5;

public class ClassR 
{
	void meth1()
	{
		int arr[]= {10,20,30,40,50};
		System.out.println(arr[4]);
	}
	public static void main(String[] args)
	{
		new ClassR().meth1();
		
	}
}
