package pack5;

public class ClassK 
{
	void meth1()
	{
		int arr[]= {10,20,30,30,20,40};
		for(int i=0;i<arr.length;i++)
		{
			for(int j=i+1;j<arr.length ;j++)
			{
				if(arr[i]==arr[j])
				{
					System.out.println(arr[i]);
				}
			}
				
			
		}
	}
	public static void main(String[] args)
	{
		new ClassK().meth1();
		
	}

}
