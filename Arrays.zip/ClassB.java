package pack5;

public class ClassB
{
	void meth()
	{
		int arr[]= {1,2,3,4,5};
		int s=0;
	
		for (int i=0;i<arr.length ;i++)
		{
			s=s+arr[i];
			//int  a=s/2;
			//System.out.println(a);
				
		}
		int  a=s/2;
		System.out.println(a);
		//int  a=i/2;
		//System.out.println(a);		
	}
	public static void main(String[] args) 
	{
		new ClassB().meth();
		
	}
	

}



