package pack5;
public class ClassC
{
	void meth1()
	{
		int arr[]= {10,20,30,40,50};
		{
			for (int i=0;i<arr.length;i++) 
			{
				System.out.println(arr[i]);
			}	
		}
	}
	public static void main(String[] args) 
	{
		new ClassC().meth1();
		
	}

}
