package pack5;

public class ClassO 
{
	void meth()
	{
		int arr[]= {10,2,12,23,54};
		boolean found12=false;
		boolean found23=false;
		for(int i:arr)
		{
			if(i==12)
			{
				found12=true;
			}
			if(i==23) 
			{
				found23=true;
			}
				
		}
		
		if(found12 && found23)
		{
			System.out.println("Two are there");
		}
		else
		{
			System.out.println("Two values not there");
		}
	}
	public static void main(String[] args) {
		new ClassO().meth();
	
}
}
