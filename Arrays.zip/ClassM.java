package pack5;

public class ClassM 
{
	void meth1()
	{
		int arr[]= {1,2,3,4,5};
		for (int i=1;i<arr.length;i++)
		{
			if(i%2==0)
			System.out.print("Even numbers: "+i+"\n");
			else if(i%2!=0)
			System.out.println("Odd numbers: "+i+" ");
		}
	}
	public static void main(String[] args)
	{
		new ClassM().meth1();
		
	}

}
