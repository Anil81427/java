package pack5;

public class ClassJ
{
	void meth1()
	{
		int arr[]= {1,2,3,4,5};
		int arr1[]= {10,20,3,5};
		for (int i:arr)
		{
			for(int j:arr1) 
			{
				if(i==j)
				{
					System.out.println(i);
				}
			}
		}
		
	}
	public static void main(String[] args) 
	{
		new ClassJ().meth1();
		
	}

}
