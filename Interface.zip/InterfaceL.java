package quack2;

public interface InterfaceL extends InterfaceK
{
	void meth2();
	
}
