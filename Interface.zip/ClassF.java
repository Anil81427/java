package quack2;

public  class ClassF implements InterfaceJ
{
	public static void main(String[] args) 
	{
		ClassF fobj=new ClassF();
		fobj.meth1();
		fobj.meth2();
		
	}

	@Override
	public void meth2() {
		System.out.println("default meth2()");
		
	}
	

}
