package quack2;

public class ClassH implements INterfaceM
{
	@Override
	public void meth() 
	{
		
		System.out.println("public methods & fields");
		
	}
	public static void main(String[] args) 
	{
		INterfaceM hobj=new ClassH();
		hobj.meth();
		System.out.println("public fields a:"+a);
		System.out.println("public fields a:"+s);
		
	}

}
