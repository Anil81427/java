package quack2;

public interface InterfaceE 
{
	void meth1();
	

}
