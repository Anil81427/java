package quack2;

public abstract interface InterfaceN 
{
	
	//  private interface cant't declare as private & protected 
	//they would not  access out the class or package.

}
