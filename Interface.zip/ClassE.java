package quack2;

public class ClassE implements InterfaceH,InterfaceI
{
	public void meth1()
	{
		System.out.println("Two interface class with the same method");
	}
	public static void main(String[] args) 
	{
		new ClassE().meth1();
		
	}

}
