package quack2;

public interface InterfaceF 
{
	void meth1();

}
