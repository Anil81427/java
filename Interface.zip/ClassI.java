package quack2;

public class ClassI implements InterfaceO
{

	@Override
	public void meh1() {
		System.out.println("only public fields are allwoed & private,protected fields are not alloed ");
		
	}
	public static void main(String[] args) 
	{
		InterfaceO oobj=new ClassI();
		oobj.meh1();
	}
	
	

}
