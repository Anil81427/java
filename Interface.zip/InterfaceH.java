package quack2;

public interface InterfaceH 
{
	void meth1();

}
