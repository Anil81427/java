package quack2;

public interface InterfaceI 
{
	void meth1();

}
