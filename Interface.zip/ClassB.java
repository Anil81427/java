package quack2;

public class ClassB implements InterfaceC
{
	public void  meth1()
	{
		System.out.println("meth1 Called");
	}

	public void meth2()
	{
		System.out.println("meth2() called");
	}
	public static void main(String[] args)
	{
		InterfaceC cobj=new ClassB();
		cobj.meth1();
		cobj.meth2();
			
		
			
			
		
	}


}
