package quack2;

public class ClassJ implements InterfaceP
{

	@Override
	public void meth1() 
	{
		
		System.out.println("static final variables");
		
	}
	public static void main(String[] args)
	{
		InterfaceP pobj=new ClassJ();
		pobj.meth1();
		System.out.println("static variable a1:"+a1);
		System.out.println("final variables a:"+a12);
		System.out.println("static final variables a:"+a);
	} 
	
	

}
