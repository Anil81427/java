package quack2;

public interface InterfaceA
{
	public void met1();

	

}
