package quack2;

public interface InterfaceK 
{
	void meth1();
	
	

}
