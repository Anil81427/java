package quack2;

public class ClassD implements InterfaceG,InterfaceF
{
	public void meth1()
	{
		System.out.println("meth1() to call implemented methods in the implemnted Class ");
	}
	public void meth2()
	{
		System.out.println("meth2() to call implemented methods in the implemnted Class");
	}
	public static void main(String[] args) 
	{
		InterfaceF fobj=new ClassD();
		fobj.meth1();
		InterfaceG gobj=new ClassD();
		gobj.meth2();
	}
}
