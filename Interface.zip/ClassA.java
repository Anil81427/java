package quack2;

public class ClassA implements InterfaceA
{
	
	public void met1()
	{
		System.out.println("meth1 Called");
	}
	public static void main(String[] args)
	{
		InterfaceA aobj=new ClassA();
		aobj.met1();
		
	}
}
