package quack2;

public interface InterfaceC 
{
	void meth1();
	void meth2();

}
