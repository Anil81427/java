package quack2;

public interface InterfaceP 
{
	static int a1=10;
	static final int a=4;
	final int a12=15;
	void meth1();

}
