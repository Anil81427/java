package quack2;

public class ClassG implements InterfaceL
{

	@Override
	public void meth1() {
		System.out.println("Inherit Interface to class meth1()");
		
	}

	@Override
	public void meth2() {
		System.out.println("Inherit Interface to class meth2()");
		
	}
	public static void main(String[] args) 
	{
		InterfaceL gobj=new ClassG();
		gobj.meth1();
		gobj.meth1();
	}
	

}
