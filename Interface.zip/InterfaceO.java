package quack2;

public  interface InterfaceO 
{
	//In java private & protected fields are not there
	
		//private int a=20;
		public int a1=10;
		//protected int a12=15;
		void meh1();
	

}
