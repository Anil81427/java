package quack2;

public interface InterfaceG 
{
	void meth2();

}
