package quack2;

public interface InterfaceJ
{
	
	default void meth1()
	{
		System.out.println("default method");
	}
	void meth2();
	

}
