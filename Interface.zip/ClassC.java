package quack2;

public class ClassC implements InterfaceE
{
	public void meth1()
	{
		System.out.println("Hello world");
	}
	public static void main(String[] args)
	{
		InterfaceE eobj=new ClassC();
		eobj.meth1();
	}
}
