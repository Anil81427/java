package quack2;

public interface INterfaceM
{
	public int a=10;
	public String s="java";
	public void meth();

}
