package Pack4;

public class ClassI 
{
	void meth1(int n)
	{
		int s=0;
		for (int i=1;i<=n;i++)
		{
			if(n%i==0)
			{
				s=s+1;
			}
		}
		
		if(s==2)
		{
			System.out.println("prime");
		}
		else
		{
			System.out.println("not");
		}
	}
	
	public static void main(String[] args)
	{
		new ClassI().meth1(3);
		
	}

}
