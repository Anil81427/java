package Pack4;

public class ClassF 
{
	void meth1(int a)
	{
		while(a<100)
		{
			a++;
			if(a%2==0)
			{
				System.out.println(a);
			}
		}
	}
	public static void main(String[] args) 
	{
		new ClassF().meth1(10);
		
	}

}
