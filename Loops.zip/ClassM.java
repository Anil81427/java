package Pack4;

public class ClassM 
{ 
	void meth1(int a,int b,int c)
	{
		if((a>b) &&  (a>c))
		{
			System.out.println("A valu is bigger");
		}
		else if((b>a) && (b>c))
		{
			System.out.println("B is bigger");
		}
		else
		{
			System.out.println("c value is bigger");
		}
	}
	public static void main(String[] args) 
	{
		new ClassM().meth1(10,20,30);
		
	} 
}


