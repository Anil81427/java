package Pack4;

public class ClassE
{
	void meth1(int a,int b,int c)
	{
		if((a>b) && (a>c))
		{
			System.out.println("a value is greater");
		}
		else if((b>a) && (b>c))
		{
			System.out.println("b value is greater");
		}
		else
		{
			System.out.println("c value is graeter");
		}
			
	}
	public static void main(String[] args) 
	{
		new ClassE().meth1(0,0,0);
		
	}

}
