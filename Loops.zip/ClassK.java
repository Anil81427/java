package Pack4;

public class ClassK 
{
	void meth(int n)
	{
		switch (n%2) 
		{
		case 0:
			System.out.println(n+" is even");
			break;
		case 1:
			System.out.println(n+" is odd");
			break;
		default:
			System.out.println("unexcepeted output");
		}		
	}
	public static void main(String[] args) 
	{
		new ClassK().meth(5);
		
	}
	

}
