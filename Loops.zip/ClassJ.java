package Pack4;

public class ClassJ 
{
	void meth1(int n)
	{
		int s=0;
		int tem=n;
		while(n!=0)
		{
			int a=n%10;
			s=s*10+a;
			n=n/10;
		}
		if(tem==s)
		{
			System.out.println("Palindrome");	
		}
		else
		{
			System.out.println("not Palindrome");
		}
	}
	public static void main(String[] args)
	{
		new ClassJ().meth1(121);
		
	}
}
