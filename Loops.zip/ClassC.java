package Pack4;

public class ClassC 
{
	void meth1(int n,int n1)
	{
		if(n==n1)
		{
			System.out.println("Both are equal");
		}
		else
		{
			System.out.println("Both are not equal");
		}
	}
	public static void main(String[] args)
	{
		new ClassC().meth1(5,6);
		
	}

}
