package Pack4;

public class ClassH 
{
	void meth1(int n)
	{
		int temp=n;
		int s=0;
		while (n>0)
		{
			int a=n%10;
			s=s+a*a*a;
			n=n/10;
		}
		if(s==temp)
		{
			System.out.println("armstrong");
		}
		else
		{
			System.out.println("Not an Armstrong");
		}
	}
	public static void main(String[] args)
	{
		new ClassH().meth1(153);
		
	}
}
