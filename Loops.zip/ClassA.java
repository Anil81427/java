package Pack4;
public class ClassA 
{
	void meth1(String s)
	{
	for(int i=1;i<=10;i++)
	{
	 System.out.println(s);
	}
	
	}
	public static void main(String[] args) 
	{
		new ClassA().meth1("Brigt IT Career");
		
	}
}
