package Pack4;

public class ClassB
{
	void meth1(int a)
	{
		
		while(a<20)
		{
			
			System.out.println(++a);
		}
	}
	public static void main(String[] args) 
	{
		new ClassB().meth1(0);
		
	}

}
