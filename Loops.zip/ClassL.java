package Pack4;

public class ClassL 
{
	void meth1(char gender)
	{
		switch (gender)
		{
		case 'M','m':
			System.out.println("Gender is male");
			break;
		case 'F','f':
			System.out.println("Gender is female");
			break;
		default:
			System.out.println("invalid output");
		}
	}
	public static void main(String[] args)
	{
		new ClassL().meth1('M');
		
	}

}
