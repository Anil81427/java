package Pack4;

public class ClassG
{
	void meth1(int a)
	{
		do 
		{
			System.out.println(a);
			a++;
		}
		while(a<=10);
		
	}
	public static void main(String[] args) 
	{
		new ClassG().meth1(1);
		
	}
	

}
