package pack8;

public class ClassL extends ClassJ
{
	String c="ClassL";
	@Override
	public void meth1()
	{
		System.out.println(c);
	}
	public static void main(String[] args) 
	{
		ClassJ jobj=new ClassK();
		jobj.meth1();
		ClassJ jobj1=new ClassL();
		jobj1.meth1();
		
	}
}
