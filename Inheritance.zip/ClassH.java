package pack8;

public class ClassH extends ClassG
{
	public void meth1()
	{
		System.out.println("ClassH meth1");
	}
	public void meth2()
	{
		System.out.println("ClassH meth2");
	}
	@Override
	public void meth3()
	{
		System.out.println("ClassH over ridden meth3");
	}
	public static void main(String[] args)
	{
		ClassG gobj=new ClassH();
		//gobj.meth1();
		//gobj.meth2();
		gobj.meth3();
		
		ClassG g1obj=new ClassI();
		g1obj.meth3();
		
	}

}
