package pack8;

class ClassD
{
	public void meth1()
	{
		System.out.println("classD meth1");
	}
	public void meth2()
	{
		System.out.println("classD meth2");
	}
	public void meth3()
	{
		System.out.println("classD meth1");
	}

}
