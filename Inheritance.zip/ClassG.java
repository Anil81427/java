package pack8;

public class ClassG
{
	public void meth1()
	{
		System.out.println("ClassG meth1");
	}
	public void meth2()
	{
		System.out.println("ClassG meth2");
	}
	public void meth3()
	{
		System.out.println("ClassG meth3");
	}
}
