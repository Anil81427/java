package pack8;

public class ClassK extends ClassJ
{
	String b="ClassK";
	@Override
	public void meth1() 
	{
		System.out.println(b);
	}

}
