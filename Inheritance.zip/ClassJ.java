package pack8;

public class ClassJ 
{
	String a="ClassJ";
	void meth1()
	{
		System.out.println(a);
	}

}
