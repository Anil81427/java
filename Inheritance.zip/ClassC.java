package pack8;

public class ClassC extends ClassA 
{
	public void meth1()
	{
		System.out.println("ClassC meth1");
	}
	public void meth2()
	{
		System.out.println("ClassC meth2");
	}
	public void meth3()
	{
		System.out.println("ClassC meth3");
	}
	public static void main(String[] args) 
	{
		ClassA aobj=new ClassA();
		aobj.meth1();
		aobj.meth2();
		aobj.meth3();
		
		ClassB bobj=new ClassB();
		bobj.meth1();
		bobj.meth2();
		bobj.meth3();
		
		ClassC cobj=new ClassC();
		cobj.meth1();
		cobj.meth2();
		cobj.meth3();
		
	}

}
