package pack8;

class ClassF extends ClassD
{
	public void meth()
	{
		System.out.println("classF meth1");
	}
	public void meth2()
	{
		System.out.println("classF meth3");
	}
	@Override
	public void meth3()
	{
		System.out.println("classF override meth3");
		
	}
	public static void main(String[] args) 
	{
		ClassD dobj=new ClassD();
		dobj.meth1();
		dobj.meth2();
		dobj.meth3();
		
		ClassE eobj=new ClassE();
		eobj.meth();
		eobj.meth2();eobj.meth3();eobj.meth1();
		
		ClassF fobj=new ClassF();
		fobj.meth();
		fobj.meth1();
		fobj.meth2();
		fobj.meth3();
		
		
		
		
	}

}
