package pack8;

public class ClassA
{
	public void meth1()
	{
		System.out.println("ClassA meth1");
	}
	public void meth2()
	{
		System.out.println("ClassA meth2");
	}
	public void meth3()
	{
		System.out.println("ClassA meth3");
	}

}
