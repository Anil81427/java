package pack8;

public class ClassE extends ClassD
{
	public void meth()
	{
		System.out.println("classE meth1");
	}
	public void meth2()
	{
		System.out.println("classE meth2");
	}
	@Override
	public void meth3()
	{
		System.out.println("classE override meth3");
	}
	

}
