package pack8;

public class ClassI extends ClassG
{
	public void meth1()
	{
		System.out.println("ClassI meth1");
	}
	public void meth2()
	{
		System.out.println("ClassI meth12");
	}
	@Override
	public void meth3()
	{
		System.out.println("ClassI overridden meth3");
	}

}
