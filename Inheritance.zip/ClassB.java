package pack8;

public class ClassB extends ClassA
{
	public void meth1()
	{
		System.out.println("ClassB meth1");
	}
	public void meth2()
	{
		System.out.println("ClassB meth2");
	}
	@Override
	public void meth3()
	{
		System.out.println("ClassB meth3 override");
	}

}
