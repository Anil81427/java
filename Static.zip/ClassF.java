package pack6;

public class ClassF
{
	static int a=10; 
	static int b=20;
	static int c=50;
	int a1=30;
	int b1=40;
	void meth1()
	{
		System.out.println("static variables: "+ClassF.a);
		System.out.println("static variables: "+ClassF.b);
		System.out.println("static variables: "+c);
		System.out.println("instance variables: "+a1);
		System.out.println("instance variables: "+new ClassF().b1);
	}
	
	
	public static void main(String[] args) 
	{
		new ClassF().meth1();
		
	}
	
}
