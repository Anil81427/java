package pack6;

public class ClassB 
{
	
	int a=10;
	int b=20;
	public static void meth2()
	{
		System.out.println(new ClassB().a);
		System.out.println(new ClassB().b);
	}
	public static void main(String[] args) 
	{
		ClassB.meth2();
		
	}
}
