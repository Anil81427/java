package pack6;

public class ClassC 
{
	static int a=10;
	static int b=20;
	void meth1()
	{
		System.out.println(a);
		System.out.println(b);
	}
	public static void main(String[] args)
	{
		new ClassC().meth1();
		
	}

}
