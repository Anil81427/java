package pack6;

public class ClassG 
{
	public static void meth()
	{
		System.out.println("static method");
	}
	void meth1()
	{
		System.out.println("instance method");
	}
	public static void main(String[] args) 
	{
		ClassG.meth();
		new ClassG().meth1();
	}

}
