package pack6;

public class ClassD 
{
	void meth()
	{
		System.out.println("Instance method");
	}
	static void meth1()
	{
		System.out.println("stastic method");
		ClassD aobj=new ClassD();
		aobj.meth();
	}
	public static void main(String[] args)
	{
		ClassD.meth1();
		
	}

}
