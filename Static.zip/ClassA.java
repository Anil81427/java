package pack6;

public class ClassA
{
	static int c=10;
	static int d=20;
	int a=15;
	int b=30;
	static void meth1( )
	{
		System.out.println("static meth1: "+c);
	}
	
	public static void meth2()
	{
		System.out.println("static method2: "+d);
	}
	void meth3()
	{
		System.out.println("instance method1: "+a);
	}
	void meth4()
	{
		System.out.println("instance method2: "+b);
	}
	public static void main(String[] args) 
	{
		
		ClassA.meth1();
		ClassA.meth2();
		new ClassA().meth3();
		new ClassA().meth4();
		
	}

}
