package pack6;

public class ClassE 
{
	public static void meth()
	{
		System.out.println("static method");
	}
	void meth1()
	{
		System.out.println("instance method");
		ClassE.meth();
	}
	public static void main(String[] args) 
	{
		new ClassE().meth1();
		
	}

}
