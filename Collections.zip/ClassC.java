package quack8;

import java.util.HashSet;
import java.util.Iterator;

public class ClassC 
{
	void meth1()
	{
		HashSet<String> hs=new HashSet<String>();
		hs.add("java");
		hs.add("object");
		hs.add("programming");
		hs.add("language");
		hs.add("oriented");
		hs.add("dell");
		hs.add("hp");
		hs.add("collection");
		hs.add("framework");
		hs.add("hashset");
		System.out.println(hs);
		System.out.println(hs.size());
		System.out.println(hs.remove("java"));
		System.out.println(hs.isEmpty());
		hs.add("set");
		hs.add("add");
		System.out.println(hs.addAll(hs));
		Iterator<String> i=hs.iterator();
		while(i.hasNext())
		{
			System.out.println(i.next());
		}
		
		
	}
	public static void main(String[] args)
	{
		new ClassC().meth1();
		
	}

}
