package quack8;

import java.util.ArrayList;
import java.util.Iterator;

public class ClassA 
{
	void meth1()
	{
		ArrayList<String> al=new ArrayList<String>();
		al.add("java");
		al.add("awesome");
		al.add("object");
		al.add("progragramming");
		al.add("language");
		al.add("oriented");
		al.add("laptop");
		al.add("collections");
		al.add("framework");
		al.add("arrays");
		System.out.println(al+"\n");
		System.out.println(al.get(5));
		Iterator<String> i=al.iterator();
		{
			while(i.hasNext())
			{
				System.out.print(i.next()+" ");
			}
		}
		//System.out.println(al.get(5));
		al.add(0,"kum");
		System.out.println(al);
		System.out.println(al.size());
		System.out.println((al.contains("java")));
		System.out.println(al.isEmpty());
		System.out.println(al.remove(0));
		System.out.println();
	}
	
	public static void main(String[] args) 
	{
		new ClassA().meth1();
		
	}

}
