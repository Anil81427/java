package quack8;

import java.util.HashMap;

public class ClassB 
{
	void meth1()
	{
		HashMap<Object,Object> map=new HashMap<Object,Object>();
		map.put(10,"java");
		map.put(20,"object");
		map.put(30,"oriented");
		map.put(40,"programming");
		map.put(30,"language");
		map.put(50,"collections");
		map.put(60,"frameworks");
		map.put(70,"hashmap");
		map.put(80,"laptop");
		map.put(90,"hp");
		map.put(65,"dell");
		System.out.println(map);
		System.out.println(map.get(50));
		
		@SuppressWarnings("unchecked")
		HashMap<Integer,String> clone=(HashMap<Integer,String>) map.clone();
		System.out.println(clone);
		
		System.out.println(map.containsKey(65));
		
		System.out.println(map.containsValue("hp"));
		
		System.out.println(map.isEmpty());
		System.out.println(map.size());
		
		System.out.println(map.keySet());
		
		System.out.println(map.values());
		
		System.out.println(map.remove(90));
		HashMap<Object,Object> mapnew=new HashMap<Object,Object>(map);
		System.out.println(mapnew);
	}
	
	public static void main(String[] args) 
	{
		new ClassB().meth1();
		
	}

}
