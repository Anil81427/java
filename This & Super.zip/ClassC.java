package quack3;

public class ClassC extends ClassB
{
	public ClassC()
	{
		System.out.println(super.a);
		System.out.println(super.s);
	}
	public static void main(String[] args)
	{
		ClassB bobj=new ClassC();
		bobj.meth1();
		
	}

}
