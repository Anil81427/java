package quack3;

public class ClassI extends ClassH
{
	public void callmeth1()
	{
		this.meth1();
	}
	void callmeth2()
	{
		super.meth2();
	}
	public static void main(String[] args)
	{
		new ClassI().callmeth1();
		new ClassI().callmeth2();
	}
}
