package quack3;

public class ClassE 
{
	int a;
	String s;

	void meth1()
	{
		System.out.println("meth1() called");
	}
	ClassE()
	{
		this(10,"java");
		System.out.println("Non parameterized constructor");
	}
	public ClassE(int a, String s)
	{
		System.out.println("parameterized constructor");
		this.a=a;
		this.s=s;
		System.out.println(a);
		System.out.println(s);
	}
	public static void main(String[] args) 
	{
		new ClassE().meth1();
		
	}

}
