package quack3;

public class ClassG extends ClassF
{
	void meth1()
	{
		System.out.println("meth1 Called");
	}
	ClassG()
	{
		super(10);
	}
	public static void main(String[] args) 
	{
		new ClassG().meth1();;
		
		
	}

}
