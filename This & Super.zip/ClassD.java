package quack3;

public class ClassD
{
	void meth1()
	{
		System.out.println("meth1() called");
	}
	ClassD(int a,int b)
	{
		this();
		System.out.println("parameterized constructor");
		System.out.println("a:"+a);
		System.out.println("b:"+b);
	}
	
	
	public ClassD() {
		System.out.println("non parameterized constructor");
	}
	public static void main(String[] args)
	{
		ClassD dobj=new ClassD(10,20);
		dobj.meth1();
	}

}
