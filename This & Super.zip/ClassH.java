package quack3;

public class ClassH
{
	int a=10;
	String s="java";
	public void meth1()
	{
		System.out.println("meth1 called");
		
	}
	public void meth2()
	{
		System.out.println("meth2() called");
	}
	
	

}
