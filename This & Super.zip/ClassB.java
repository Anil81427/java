package quack3;

public class ClassB 
{
	int a=10;
	String s="java";
	
	public void meth1()
	{
		System.out.println("calling parent fields & members into child class");
	}
	

}
