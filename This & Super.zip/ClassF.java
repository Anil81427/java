package quack3;

public class ClassF 
{
	public ClassF(int a)
	{
		System.out.println("super() method");
	}

}
