package quack3;

public class ClassA 
{
	int a=10;
	String s="java";
	void meth1()
	{
		System.out.println(this.a);
		System.out.println(this.s);
	}
	public static void main(String[] args) 
	{
		
		new ClassA().meth1();
	}

}
