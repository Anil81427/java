package quack1;

public class ClassI extends ClassH
{
	public static void main(String[] args) 
	{
		ClassH hobj=new ClassI();
		hobj.meth1();
		hobj.meth2();
	}

}
