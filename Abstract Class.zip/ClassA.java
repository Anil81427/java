package quack1;
import pack9.ClassG;
public class ClassA extends ClassG
{
	public ClassA(int a, String s) 
	{
		super(10, "java");
	}
	public static void main(String[] args)
	{
		ClassA aobj=new ClassA(10, "java");
		aobj.meth();
		
		
	}
	

}
