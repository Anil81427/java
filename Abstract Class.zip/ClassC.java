package quack1;

public class ClassC extends ClassB
{
	@Override
	void meth1()
	{
		System.out.println("classB meth1() override");
	}
	public static void main(String[] args) 
	{
		ClassB bobj=new ClassC();
		bobj.meth1();
		bobj.meth2();
		
	}

}
