package quack1;

public abstract class ClassF 
{
	abstract void meth1();
	abstract void meth2();

}
