package quack1;

public class ClassE extends ClassD
{
	
	public static void main(String[] args)
	{
		ClassD dobj=new ClassE();
		dobj.meth1();
	}
	

}
