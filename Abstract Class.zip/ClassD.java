package quack1;

public abstract class ClassD
{
	
	void meth1()
	{
		System.out.println("non abstract method");
	}

}
