package quack1;

public class ClassG extends ClassF
{
	@Override
	void meth1()
	{
		System.out.println("abstract method1");
	}
	void meth2()
	{
		System.out.println("abstract method2");
	}
	public static void main(String[] args)
	{
		ClassF fobj=new ClassG();
		fobj.meth1();
		fobj.meth2();
		
	}

}
