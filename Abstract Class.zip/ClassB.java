package quack1;

public abstract class ClassB 
{
	abstract void meth1();
	void meth2()
	{
		System.out.println("non-abstract method");
	}

}
