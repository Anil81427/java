package quack1;

public abstract class ClassH 
{
	void meth1()
	{
		System.out.println("non abstract meth1");
	}
	void meth2()
	{
		System.out.println("non abstract meth2");
	}
}
