package pack9;

public class ClassC 
{
	int a;
	String s;
	char c;
	void meth1()
	{
		System.out.println("default meth1");
	}
	public ClassC(int a,String s,char c)
	{
		System.out.println("parameterized constractor");
		System.out.println(a);
		System.out.println(s);
		System.out.println(c);
	}
}
