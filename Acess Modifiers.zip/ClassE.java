package pack9;

public class ClassE 
{
	protected int a;
	protected String s;
	protected void meth()
	{
		System.out.println("protected method");
		
	}
	ClassE(int a,String s)
	{
		System.out.println("parameterized constructor");
		System.out.println(a);
		System.out.println(s);
	}

}
