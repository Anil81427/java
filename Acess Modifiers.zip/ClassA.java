package pack9;

public class ClassA
{
	private int a=10;
	private String S="java";
	private char c='a';
	
	public void meth()
	{
	System.out.println("private method");
	
	}
	
	public int getA() {
		return a;
	}

	public void setA(int a) {
		this.a = a;
	}

	public String getS() {
		return S;
	}

	public void setS(String s) {
		S = s;
	}

	public char getC() {
		return c;
	}

	public void setC(char c) {
		this.c = c;
	}

	
	
	

}
