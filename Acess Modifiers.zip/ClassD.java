package pack9;

public class ClassD 
{
	public static void main(String[] args)
	{
		ClassC aobj=new ClassC(10,"java",'a');
		aobj.meth1();
	}
}
		
		
	