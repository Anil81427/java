package pack9;

public class ClassH 
{
	public int a=10;
	public String s="java";
	public void meth()
	{
		System.out.println("meth1() called");
		System.out.println(a);
		System.out.println(s);
	}

}
