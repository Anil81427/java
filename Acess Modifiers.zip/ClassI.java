package pack9;

public class ClassI 
{
	public static void main(String[] args)
	{
		new ClassH().meth();
		
		
	}

}
