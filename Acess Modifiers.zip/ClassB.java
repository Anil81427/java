package pack9;

public class ClassB
{
	public static void main(String[] args) 
	{
		ClassA aobj=new ClassA();
		aobj.meth();
		System.out.println(aobj.getA());
		System.out.println(aobj.getS());
		System.out.println(aobj.getC());
		
		
	}

}
