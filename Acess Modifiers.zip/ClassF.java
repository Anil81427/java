package pack9;

public class ClassF 
{
	
	public static void main(String[] args)
	{
		ClassE eobj=new ClassE(10,"java");
		eobj.meth();
		
		
	}

}
