package pack9;

public class ClassG 
{
	protected int a;
	protected String s;
	protected void meth()
	{
		System.out.println("protected method");
		
	}
	public ClassG(int a,String s)
	{
		System.out.println("parameterized constructor");
		System.out.println(a);
		System.out.println(s);
	}

}
