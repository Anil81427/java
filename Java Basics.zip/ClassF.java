package pack2;

public class ClassF
{
	void meth1()
	{
		System.out.println("class is an blue print of an object");
		/**
		 * syntax:
		 * access modifier Class Classname
		 * {
		 * 
		 * }
		 */
	}
	public static void main(String[] args) 
	{
		new ClassF().meth1();//creating an object
		
	}

}
