package pack2;

public class ClassB
{
	void meth1(int a,int b)
	{
		//single line Comment
		System.out.println("Single Line Comment");
		
		/*Multi-level comments
		 * Enter a First number & second number
		*/
		System.out.println("multi Level comments");
		
		/**
		 * Documentation level Comments
		 * Enter a First number
		 * Enter a second number
		 */
		System.out.println("Documentation Comments");
		int c=a+b;
		System.out.println("c:"+c);
		
	}public static void main(String[] args) 
	{
		new ClassB().meth1(10,20);
		
	}
	

}
