package pack2;

public class ClassA
{
	void meth1() {
		System.out.println("Anil Vusa");
	}
	public static void main(String[] args) 
	{
		new ClassA().meth1();
	}

}
