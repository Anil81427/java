package pack2;

public class ClassE
{
	void meth1(String name)
	{
		System.out.println("Hi: "+name);
	}
	public static void main(String[] args) 
	{
		ClassE aobj=new ClassE();
		aobj.meth1("Anil");
		
	}
}
