package pack2;



public class ClassD 
{
	int a=10;
	void meth1()
	{
		int a=100;
		System.out.println(a);
	}
	
	public static void main(String[] args) 
	{
		new ClassD().meth1();
		
	}

}
//scope of a variable is local variable 