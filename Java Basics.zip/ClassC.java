package pack2;

public class ClassC 
{
	void meth1()
	{
		int a=10;
		boolean b=false;
		char c='A';
		float d=10;
		double e=10;
		System.out.println(a);
		System.out.println(b);
		System.out.println(c);
		System.out.println(d);
		System.out.println(e);
	}
	public static void main(String[] args)
	{
		new ClassC().meth1();
		
	}

}
