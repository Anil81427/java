package quack6;

public class ClassN 
{
	void meth1()
	{
		String s="java";
		try
		{
			System.out.println(s.charAt(5));
		}
		catch (Exception e) 
		{
			
			e.printStackTrace();
		}
	}
	public static void main(String[] args)
	{
		new ClassN().meth1();
		
	}

}
