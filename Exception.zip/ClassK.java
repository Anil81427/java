package quack6;

import java.io.File;
import java.io.FileReader;

public class ClassK
{
	void meth1()
	{
		try
		{
			File f=new File("c:\file/file1");
			try (FileReader filereader = new FileReader(f)) 
			{
				filereader.read();
			}
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		
	}public static void main(String[] args)
	{
		
		new ClassK().meth1();
	}
	


}
