package quack6;
public class ClassG 
{
	void meth1()
	{
		try
		{
			
			System.out.println("ArithmeticException");
			
			System.out.println(2/0);
			
		}
		catch (Exception e) {
			e.printStackTrace();
		}
	
		finally 
		{
			System.out.println("finally block");
		}
	}
	public static void main(String[] args)
	{
		new ClassG().meth1();
		
	}
}
