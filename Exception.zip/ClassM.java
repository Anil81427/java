package quack6;




public class ClassM
{
	String s=null;
	void meth1()
	{
		try
		{
			s.length();
		}
		catch (Exception e) 
		{
			
			e.printStackTrace();
		}
	}
	public static void main(String[] args)
	{
		new ClassM().meth1();
		
	}
}
