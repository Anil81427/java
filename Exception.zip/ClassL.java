package quack6;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

public class ClassL 
{
	void met1() 
	{
		File file=new File("C:\file\file4.txt");
		try(FileInputStream fis=new FileInputStream(file))
		
		{
			System.out.println("file opened");
		}
		catch(IOException e)
		{
			System.out.println("IOException"+e.getMessage());
			e.printStackTrace();
		}
	}
	public static void main(String[] args) throws Exception
	{
		new ClassL().met1();
		
	}
	
	

}
