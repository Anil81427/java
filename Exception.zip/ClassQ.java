package quack6;

public class ClassQ
{
	public static void main(String[] args)
	
	{
		try
		{
			throw new NoSuchFieldException();
		}
		catch (Exception e) 
		{
			e.printStackTrace();
			// TODO: handle exception
		}
		
	}
	



}



