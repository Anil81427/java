package quack6;



public class ClassR 
{
	public static void main(String[] args)
	{
		try
		{
			throw new NoSuchMethodException();
		}
		catch (Exception e)
		{
			e.printStackTrace();
			System.out.println(e.getMessage());
			// TODO: handle exception
		}
		
	}
	
}
	


