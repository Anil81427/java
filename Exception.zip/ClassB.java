package quack6;

public class ClassB
{
	void meth1()
	{
		try
		{
			System.out.println(2/0);
		}
		catch (Exception e) 
		{
			System.out.println("zero cant divisible by 2 so execption");
			
		}
	}
	public static void main(String[] args) 
	{
		new ClassB().meth1();
		
	}

}
