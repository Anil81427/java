package quack6;

public class ClassF 
{
	
}
