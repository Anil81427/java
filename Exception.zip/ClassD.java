package quack6;

public class ClassD 
{
	public static void main(String[] args) 
	{
		try
		{
			System.out.println("multiple catch blocks");
			System.out.println(2/0);
			String s=null;
			System.out.println(s);
		}
		catch (ArithmeticException e) 
		{
			
			System.out.println("ArithmeticException");
		}
		catch (NullPointerException e)
		{
			System.out.println("NullPointerException");
		}
		catch (Exception e) 
		{
			System.out.println("Exception");
			
	}
		
		
	}

}
