package quack6;

public class ClassC
{
	void meth1()
	{
		System.out.println(2/0);
	}
	public static void main(String[] args) throws Exception 
	{
		new ClassC().meth1();
		
	}

}
