package quack6;

public class ClassI 
{
	public static void main(String[] args) 
	{
		int arr[]= {10,20,30,40};
		try 
		{
			System.out.println(arr[4]);
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}
	

}
