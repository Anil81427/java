package quack6;

public class ClassH 
{
	void meth1()
	{
		try 
		{
			System.out.println(15/0);
		}
		catch (Exception e) 
		{
			e.printStackTrace();
		}
		finally {
			System.out.println("finally block");
		}
	}
	public static void main(String[] args) 
	{
		new ClassH().meth1();
		
	}

}
