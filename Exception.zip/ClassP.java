package quack6;

import java.sql.Statement;
import java.net.ConnectException;

import java.sql.DriverManager;

public class ClassP
{
	void meth1()
	{
		try
		{
			String s="Sql exception";
			String s1="root";
			String s2="password";
			Connection connection=DriverManager.getconnection(s,s1,s2);
			//connection.executeQuery(s3);
			String s3="select * from employee";
			connection.executeQuery(s3);
			statement.executeQuery(s3);
		}
		catch (Exception e) 
		{
			System.out.println(e.getMessage());
			e.printStackTrace();
			// TODO: handle exception
		}
	}
	public static void main(String[] args)
	{
		new ClassP().meth1();
		
	}

}
