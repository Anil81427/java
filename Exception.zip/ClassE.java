package quack6;

public class ClassE
{
	void meth1()
	{
		try
		{
			System.out.println("own Exception");
		}
		catch (Exception e) 
		{
			
			e.printStackTrace();
		}
	}		
	public static void main(String[] args) throws Exception
	{
		
		new ClassE().meth1();
	}

}
