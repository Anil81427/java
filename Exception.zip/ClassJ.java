package quack6;

public class ClassJ 
{
	void meth1()
	{
		try
	{
		Class.forName("non existingClass");
	}

	
	catch(Exception e)
	{
		e.printStackTrace();
	}
	}
	public static void main(String[] args) 
	{
		new ClassJ().meth1();
		
	}

}
