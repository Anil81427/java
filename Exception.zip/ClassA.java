package quack6;

public class ClassA
{
	void meth1()
	{
		try 
		{
			System.out.println(2/0);
			
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	public static void main(String[] args) 
	{
		new ClassA().meth1();
		
	}

}
