package quack6;

public class ClassO 
{
	
	void meth1()
	{
		try
		{
			String s="java";
			int n=Integer.parseInt(s);System.out.println(n);
		}
		catch (Exception e) 
		{
			e.printStackTrace();
			// TODO: handle exception
		}
	}
	public static void main(String[] args) 
	{
		new ClassO().meth1();
		
	}

}
