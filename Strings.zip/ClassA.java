package pack7;



public class ClassA
{
	void meth()
	{
		String s="hello world";
		String s1=new String("kishan");
		StringBuffer sb=new StringBuffer("hello");
		StringBuilder sb1=new StringBuilder("world");
		System.out.println(s);
		System.out.println(s1);
		System.out.println(sb);
		System.out.println(sb1);
	}
	public static void main(String[] args)
	{
		new ClassA().meth();
		
	}

}
