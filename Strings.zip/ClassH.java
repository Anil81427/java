package pack7;



public class ClassH 
{
	void meth1()
	{
		 String s1="java";
		 String s2="java";
		 //a=s1.startsWith(s2);
		 //boolean b=s1.endsWith(s2);
		// s1.compareTo(s2);
		 if(s1.equalsIgnoreCase(s2))
		 {
			 System.out.println("strings are equalIgnorecase");
		 }
		 else
		 {
			 System.out.println("strings are not equalIgnorecase");
		 }
	}
	void meth2()
	{
		 {
			 String a="Hello World";
			 String b="Hello";
			 if(a.startsWith(b))
			 {
				 System.out.println("String Startwith");
			 }
			 else
			 {
				 System.out.println("String not Start with");
			 }
		}
	}
	void meth3()
	{
		String n1="java is awesome";
		String n2="awesome";
		if(n1.endsWith(n2))
		{
			System.out.println("String Endswith ");
		}
		else
		{
			System.out.println("String not Endswith");
		}
	}
	void meth4()
	{
		String d="Hello";
		String d1="World";
		int result=d.compareTo(d1);
		if(result<0)
		{
			System.out.println("d comes before s1");
		}
		else if(result>0)
		{
			System.out.println("d comes after s1");
		}
		else
		{
			System.out.println("d and d1 are equal");
		}
			
	}
	public static void main(String[] args)
	{
		new ClassH().meth1();
		new ClassH().meth2();
		new ClassH().meth3();
		new ClassH().meth4();
	}

}
