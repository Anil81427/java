package pack7;

public class ClassL
{
	void meth()
	{
		int n=113;
		String n1=String.valueOf(n);
		System.out.println(n1);
	}
	public static void main(String[] args)
	{
		new ClassL().meth();
		
	}

}
