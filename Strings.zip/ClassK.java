package pack7;



public class ClassK 
{
	void meth() 
	{
	String s="Hello,world";
	String[] s1=s.split(",");
	for(String a:s1)
	{
		System.out.println(a);
	}
	//System.out.println(s1.toString());
	}
	public static void main(String[] args)
	{
		new ClassK().meth();
		
	}

	
}
