package pack7;

public class CLassM
{
	void meth()
	{
		int num=12345;
		
		String num1=String.valueOf(num);
		System.out.println(num1);

		
	}
	public static void main(String[] args) 
	{
		new CLassM().meth();
		
	}

}
