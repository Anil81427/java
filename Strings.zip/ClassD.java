package pack7;

public class ClassD
{
	void meth()
	{ System.out.println("Extract a string using substring");
		String s="java is awesome";
		String s1=s.substring(5);
		System.out.println(s1);
	}
	public static void main(String[] args) 
	{
		new ClassD().meth();
		
	}

}
