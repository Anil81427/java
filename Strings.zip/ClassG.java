package pack7;

public class ClassG
{
	void meth()
	{
		String s1="hello";
		String s2="hello";
		if(s1.equals(s2))
		{
			System.out.println("Equals");
		}
		else
		{
			System.out.println("Not Equals");
		}
	}
	public static void main(String[] args)
	{
		new ClassG().meth();
		
	}

}
