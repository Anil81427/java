package pack7;

public class ClassE 
{
	void meth()
	{
		String s="Hello,world";
		int s1=s.indexOf("world");
		if(s1!=-1)
		{
			System.out.println("found: "+s1);
		}
		else
		{
			System.out.println("not found");
		}
				
	}
	public static void main(String[] args)
	{
		new ClassE().meth();
		
	}

}
