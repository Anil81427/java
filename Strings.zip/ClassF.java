package pack7;

public class ClassF 
{
	void meth()
	{
		String s="java";
		String s1="java";
		if(s.matches(s1)) 
		{
			System.out.println("matches");
		}
		else
		{
			System.out.println("not matches");
		}
			
	}
	public static void main(String[] args)
	{
		new ClassF().meth();
		
	}

}
