package pack7;

public class ClassN
{
	void meth()
	{
		String s="HELLO WORLD";
		String S1=s.toLowerCase();
		System.out.println(S1);
	}
	public static void main(String[] args) 
	{
		new ClassN().meth();
		
	}

}
