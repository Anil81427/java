package pack7;

public class ClassI 
{
	void meth()
	{
		String s=" hello world ";
		String s1=s.trim();
		System.out.println(s1);
	}
	public static void main(String[] args)
	{
		new ClassI().meth();
		
	}

}
