package pack7;

public class ClassB
{
	void meth1()
	{
		String s="java";
		String s1=" is awesome";
		System.out.println(s+s1);
		
	}
	public static void main(String[] args) 
	{
		new ClassB().meth1();
		
	}
	

}
