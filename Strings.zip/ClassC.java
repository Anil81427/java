package pack7;

public class ClassC 
{
	void meth1()
	{
		String s="java";
		System.out.println(s.length());
	}
	public static void main(String[] args) 
	{
		new ClassC().meth1();
		
	}
}
