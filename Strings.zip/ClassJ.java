package pack7;

public class ClassJ 
{
	void meth()
	{
	String s="java";
	String s1=s.replace('j','R');
	System.out.println(s1);
	}
	public static void main(String[] args)
	{
		new ClassJ().meth();
		
	}

}
