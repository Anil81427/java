package quack5;

public class ClassB
{
	void meth1(int a,String s)
	{
		System.out.println("a:"+a);
		System.out.println("s:"+s);
	}
	void meth1(int b,String s1,char c)
	{
		System.out.println("b:"+b);
		System.out.println("s1:"+s1);
		System.out.println("c:"+c);
	}
	public static void main(String[] args)
	{
		new ClassB().meth1(15,"java");
		new ClassB().meth1(4,"hello",'a');
	}

}
