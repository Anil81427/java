package quack5;

public class ClassA 
{
	void meth1(int a)
	{
		System.out.println("a:"+a);
		
	}
	void meth1(int b,int d)
	{
		System.out.println("b:"+b);
		
		System.out.println("d:"+d);
	}
	public static void main(String[] args) 
	{
		new ClassA().meth1(10);
		new ClassA().meth1(15,4);
		
	}

}
