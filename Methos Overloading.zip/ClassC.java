package quack5;

public class ClassC 
{
	void meth1(int a,String s)
	{
		System.out.println("a:"+a);
		System.out.println("s:"+s);
	}
	void meth1(String s1,int a)
	{
		System.out.println("s1:"+s1);
		System.out.println("a:"+a);
	}
	public static void main(String[] args)
	{
		new ClassC().meth1(33,"java");
		new ClassC().meth1("Hello",'a');
		
	}

}
