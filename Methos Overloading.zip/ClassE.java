package quack5;

public class ClassE
{
	public int meth1(int a)
	{
		System.out.println("int method()");
		return a;
	}
	public String meth1(String s)
	{
		System.out.println("String meth1()");
		return s;
	}
	public static void main(String[] args) 
	{
		new ClassE().meth1(5);
		new ClassE().meth1("java");
		
	}

}
