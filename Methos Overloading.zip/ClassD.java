package quack5;

public class ClassD
{
	void meth1(int a,String s,char c)
	{
		System.out.println("a:"+a);
		System.out.println("s:"+s);
		System.out.println("c:"+c);
	}
	void meth1(String s1,int c1,boolean b1)
	{
		System.out.println("s1:"+s1);
		System.out.println("c1:"+c1);
		System.out.println("b1:"+b1);
	}
	public static void main(String[] args) 
	{
		new ClassD().meth1(10,"java",'a');
		new ClassD().meth1("Hello", 4, false);
		
	}
	
	

}
