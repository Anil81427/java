package pack3;

public class ClassA
{
	void meth1(int a,int b)
	
	{
		System.out.println("Addition: "+(a+b));
		System.out.println("subtraction: "+(a-b));
		System.out.println("multiplication: "+(a*b));
		System.out.println("Division: "+(a/b));
	}
	public static void main(String[] args)
	{
		new ClassA().meth1(10,20);
		
	}
		
}
