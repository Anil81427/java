package pack3;

public class ClassC 
{
	void meth1(int n,int n1)
	{
		if(n==n1)
		{
			System.out.println("Equal");
		}
		else {
			System.out.println("Not equal");
		}
	}
	public static void main(String[] args)
	{
		new ClassC().meth1(5,6);
		
	}
	}