package pack3;

public class ClassF 
{
	void meth1(int n,int m)
	{
		if(n<m)
		{
			System.out.println("smaller number:"+n);
			System.out.println("larger number:"+m);
		}
		else if(n>m)
			
		{
			System.out.println("smaller number:"+m);
			System.out.println("larger number:"+n);
		}
		else
		{
			System.out.println("Both are equal");
		}
	}
	public static void main(String[] args) 
	{
		new ClassF().meth1(1100, 500);
		
		
	}

}
