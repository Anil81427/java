package pack3;

public class ClassG 
{
	void meth1(int n1,int n2)
	{
		if(n1==n2)
		{
			System.out.println("Equal operator");
		}
		else
		{
			System.out.println("not equal");
		}
	}
	public static void main(String[] args) 
	{
		new ClassG().meth1(15, 4);
		
	}

}
