package pack3;

public class ClassB 
{
	public void meth1(int a)
	{
		System.out.println("value of a:"+a);
		System.out.println("pre increment");
		System.out.println(++a);
		
		System.out.println("post increment");
		System.out.println(a++);
		
		System.out.println("pre decrement");
		System.out.println(--a);
		
		System.out.println("post decrement");
		System.out.println(a--);
	}
	public static void main(String[] args)
	{
		new ClassB().meth1(5);
		
	}

}
