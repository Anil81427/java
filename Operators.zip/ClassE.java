package pack3;

public class ClassE 
{
	void Greateroperator(int a,int b)
	{
		if(a>b)
		{
			System.out.println("a is greater");
		}
		else
		{
			System.out.println("b is lesser");
		}
	}
	void lesseroperator(int c,int d)
	{
		if(c<d) 
		{
			System.out.println("c is lesser ");
			
		}
		else
		{
			System.out.println("d is greater");
		}
		
	}
	void Greaterthanorequaloperator(int e,int f)
	{
		if(e>=f)
		{
			System.out.println("a is greater than b");
		}
		else
		{
			System.out.println("b is lesser than s");
		}
	}
	void lesserthanorequaloperator(int g,int h)
	{
		if(g<=h)
		{
			System.out.println("g is lesser than h");
		}
		else 
		{
			System.out.println("h is greater than g");
		}
	}
	
	
	public static void main(String[] args) 
	{
		new ClassE().Greateroperator(51,10);
		new ClassE().lesseroperator(15,36);
		new ClassE().Greaterthanorequaloperator(50, 10);
		new ClassE().lesserthanorequaloperator(5, 100);
	}

}
