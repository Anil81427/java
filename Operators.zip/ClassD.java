package pack3;

public class ClassD 
{
	void logicalAnd(int a,int b)
	{
		
		if((a<b) && (a>b))
		{
			System.out.println("And");
		}
		
		else if((a>b) || (a<b))
		{
			System.out.println("Or");
		}
		else
			System.out.println("not");
	}
	public static void main(String[] args)
	{
		new ClassD().logicalAnd(5,5);
		
	}

}
